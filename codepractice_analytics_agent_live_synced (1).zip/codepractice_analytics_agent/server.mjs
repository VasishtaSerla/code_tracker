import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { URL } from "node:url";

const PORT = Number(process.env.PORT || 8787);
const ROOT = path.resolve("./public");
const MODEL = process.env.OPENAI_MODEL || "gpt-6-luna";

function send(res, status, type, body) {
  res.writeHead(status, { "Content-Type": type, "Cache-Control": "no-store" });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", chunk => {
      body += chunk;
      if (body.length > 2_000_000) {
        req.destroy();
        reject(new Error("Request too large"));
      }
    });
    req.on("end", () => resolve(body));
    req.on("error", reject);
  });
}

function analyze(data) {
  const rows = Array.isArray(data) ? data : [];
  const avg = xs => xs.length ? xs.reduce((a,b) => a + Number(b || 0), 0) / xs.length : 0;
  const topicMap = new Map();

  for (const p of rows) {
    for (const raw of (p.topics || [])) {
      const t = String(raw).trim();
      if (!t) continue;
      if (!topicMap.has(t)) topicMap.set(t, []);
      topicMap.get(t).push(p);
    }
  }

  const topics = [...topicMap.entries()].map(([topic, xs]) => ({
    topic,
    solved: xs.length,
    avg_time: Math.round(avg(xs.map(x => x.time))),
    first_try_rate: Math.round(xs.filter(x => Number(x.attempts) === 1).length / xs.length * 100),
    hint_rate: Math.round(xs.filter(x => Number(x.hints) > 0).length / xs.length * 100),
    total_minutes: xs.reduce((s,x) => s + Number(x.time || 0), 0)
  })).sort((a,b) => b.total_minutes - a.total_minutes);

  const recent = [...rows].sort((a,b) => String(a.date).localeCompare(String(b.date))).slice(-7);
  const prev = [...rows].sort((a,b) => String(a.date).localeCompare(String(b.date))).slice(-14,-7);

  return {
    total_problems: rows.length,
    avg_solve_time: Math.round(avg(rows.map(x => x.time))),
    avg_attempts: Number(avg(rows.map(x => x.attempts)).toFixed(1)),
    hint_rate: Math.round(rows.filter(x => Number(x.hints) > 0).length / Math.max(rows.length,1) * 100),
    topics,
    recent: {
      n: recent.length,
      avg_time: Math.round(avg(recent.map(x => x.time))),
      first_try_rate: Math.round(recent.filter(x => Number(x.attempts) === 1).length / Math.max(recent.length,1) * 100)
    },
    previous: {
      n: prev.length,
      avg_time: Math.round(avg(prev.map(x => x.time))),
      first_try_rate: Math.round(prev.filter(x => Number(x.attempts) === 1).length / Math.max(prev.length,1) * 100)
    }
  };
}

async function callOpenAI(metrics) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    throw new Error("OPENAI_API_KEY is not set.");
  }

  const instructions = `You are a personal coding-practice coach.
Analyze only the supplied metrics. Do not invent facts or claim a trend unless the data supports it.
Your goal is to produce one concrete next action and explain it using the user's numbers.
Prefer specificity over generic motivation.
Return JSON with exactly these keys:
title: short string,
recommendation: 2-4 sentences,
why: 1-3 sentences with metric references,
next_step: one concrete action.
Keep the recommendation practical and not overwhelming.`;

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: MODEL,
      instructions,
      input: JSON.stringify(metrics),
      text: { format: { type: "json_object" } },
      max_output_tokens: 500
    })
  });

  const raw = await response.text();
  if (!response.ok) throw new Error(`OpenAI API ${response.status}: ${raw.slice(0,300)}`);

  const payload = JSON.parse(raw);
  const text = payload.output_text;
  if (!text) throw new Error("No text returned by the model.");
  return JSON.parse(text);
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://127.0.0.1:${PORT}`);

    if (req.method === "POST" && url.pathname === "/api/coach") {
      const body = JSON.parse(await readBody(req));
      const metrics = analyze(body.data);
      const result = await callOpenAI(metrics);
      return send(res, 200, "application/json; charset=utf-8", JSON.stringify(result));
    }

    if (req.method === "GET") {
      const filePath = url.pathname === "/" ? path.join(ROOT, "index.html")
        : path.join(ROOT, path.normalize(url.pathname).replace(/^(\.\.[/\\])+/, ""));
      if (!filePath.startsWith(ROOT)) return send(res, 403, "text/plain; charset=utf-8", "Forbidden");
      if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) return send(res, 404, "text/plain; charset=utf-8", "Not found");
      const ext = path.extname(filePath);
      const types = { ".html":"text/html; charset=utf-8", ".js":"text/javascript; charset=utf-8", ".css":"text/css; charset=utf-8", ".json":"application/json" };
      return send(res, 200, types[ext] || "application/octet-stream", fs.readFileSync(filePath));
    }

    return send(res, 405, "text/plain; charset=utf-8", "Method not allowed");
  } catch (err) {
    return send(res, 500, "application/json; charset=utf-8", JSON.stringify({ error: err.message }));
  }
});

server.listen(PORT, "127.0.0.1", () => {
  console.log(`CodePractice Analytics running at http://127.0.0.1:${PORT}`);
});
