# CodePractice Analytics + AI Coach

A personal coding-practice analytics dashboard with a local-first data model and an optional LLM coach.

## What it tracks

- Solved count, average solve time, attempts, hints
- Difficulty distribution
- Topic time-spend
- First-try rates
- Practice windows
- Weakness detection
- Next-session recommendations
- Daily check-in when the dashboard is opened
- JSON import/export

## Run locally

Requires Node.js 18+.

```bash
cd codepractice_analytics_agent
node server.mjs
```

Then open http://127.0.0.1:8787

The app works without an API key using its deterministic local coach.

## Enable the AI coach

Keep the API key on the server, never in the browser.

Linux/macOS:
```bash
export OPENAI_API_KEY="your_key"
export OPENAI_MODEL="gpt-6-luna"
node server.mjs
```

Windows PowerShell:
```powershell
$env:OPENAI_API_KEY="your_key"
$env:OPENAI_MODEL="gpt-6-luna"
node server.mjs
```

The server sends aggregated practice metrics to the Responses API. The API integration uses `/v1/responses`; new integrations should use the Responses API rather than the retired Assistants API.
